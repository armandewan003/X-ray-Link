package com.xraylink.client

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class XRayLinkApplication : Application()
